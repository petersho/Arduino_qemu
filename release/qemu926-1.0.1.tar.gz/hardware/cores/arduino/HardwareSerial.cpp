#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "Arduino.h"

#include "HardwareSerial.h"

void HardwareSerial::begin(unsigned long baud)
{

}

void HardwareSerial::end()
{

}

int HardwareSerial::available(void)
{
	return 0;
}

int HardwareSerial::read(void)
{
	return 0;
}
